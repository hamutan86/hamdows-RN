﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace hamdows_RN
{
    public partial class paint : Form
    {
        ArrayList listOfPoint;
        bool PencilDown;
        public paint()
        {
            InitializeComponent();
            listOfPoint = new ArrayList();
            PencilDown = false;
            comboBox1.SelectedItem = "黒";
        }

        private void paint_MouseDown(object sender, MouseEventArgs e)
        {
            Point p = new Point(e.X, e.Y);
            listOfPoint.Add(p);
            PencilDown = true;
        }

        private void paint_MouseUp(object sender, MouseEventArgs e)
        {
            PencilDown = false;
        }

        private void paint_MouseMove(object sender, MouseEventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Point points = new Point(e.X, e.Y);
            Pen pencil = new Pen(Color.Black);
            if (comboBox1.Text == "黒")
            {
                pencil = new Pen(Color.Black);
            }
            if (comboBox1.Text == "赤")
            {
                pencil = new Pen(Color.Red);
            }
            if (comboBox1.Text == "青")
            {
                pencil = new Pen(Color.Blue);
            }
            if (comboBox1.Text == "緑")
            {
                pencil = new Pen(Color.Green);
            }
            if (comboBox1.Text == "黄色")
            {
                pencil = new Pen(Color.Yellow);
            }
            if (PencilDown)
            {
                if (listOfPoint.Count > 1)
                    g.DrawLine(pencil, (Point)listOfPoint[listOfPoint.Count - 1], points);
                listOfPoint.Add(points);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}