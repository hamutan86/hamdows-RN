﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace hamdows_RN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            Random random = new Random();
            timer1.Interval = (random.Next(3300, 7700));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (File.Exists("infected.cfg"))
            {
                timer1.Stop();
                MessageBox.Show("重大なエラーが発生したため、hamdows RNを強制終了します。", "システム エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            timer1.Stop();
            this.ShowInTaskbar = false;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Size = new Size(10, 10);
            pictureBox1.Visible = false;
            label1.Visible = false;
            this.TransparencyKey = this.BackColor;
            Desktop desktop = new Desktop();
            desktop.Show();
        }
    }
}
