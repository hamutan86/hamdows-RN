﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace hamdows_RN
{
    public partial class Recyclebin : Form
    {
        public Recyclebin()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("hello, world!", "Python 3.11.0");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("本当にゴミ箱を空にしますか？" + Environment.NewLine + "ゴミ箱の中にあるファイルは全て完全に削除されます！", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                File.WriteAllText("trashcleaned.cfg", "trashcleaned");
                button1.Enabled = false;
                pictureBox2.Visible = false;
                label1.Visible = false;
                label2.Visible = true;
            }
        }

        private void Recyclebin_Load(object sender, EventArgs e)
        {
            label2.Visible = false;
            if (File.Exists("trashcleaned.cfg"))
            {
                button1.Enabled = false;
                pictureBox2.Visible = false;
                label1.Visible = false;
                label2.Visible = true;
            }
        }
    }
}
