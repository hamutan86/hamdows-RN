﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace hamdows_RN
{
    public partial class cmd : Form
    {
        public cmd()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "help")
            {
                richTextBox1.Text = "exit - コマンドプロンプトを終了します。" + Environment.NewLine + "hamver - バージョン情報を表示します。" + Environment.NewLine + "help - コマンド一覧を表示します。";
            }
            if (textBox1.Text == "exit")
            {
                this.Close();
            }
            if (textBox1.Text == "hamver")
            {
                version Version = new version();
                Version.Show();
            }
        }
    }
}
