﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace hamdows_RN
{
    public partial class Desktop : Form
    {
        public int shutdown = 0;
        public Desktop()
        {
            InitializeComponent();
        }

        private void Desktop_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (File.Exists("infected.cfg"))
            {
                Application.Exit();
            }
            else
            {
                if (shutdown == 0)
                {
                    this.TopMost = true;
                    DialogResult dialogResult = MessageBox.Show("本当にhamdows RNをシャットダウンしますか？" + Environment.NewLine + "保存していないデータがあれば保存してからシャットダウンしてください！", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult == DialogResult.Yes)
                    {
                        shutdown = 1;
                        Application.Exit();
                    }
                    else
                    {
                        e.Cancel = true;
                    }
                    this.TopMost = false;
                }
            }
        }

        private void Desktop_Load(object sender, EventArgs e)
        {
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            timer1.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button2.Visible == false)
            {
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
            }
            else
            {
                button2.Visible = false;
                button3.Visible = false;
                button4.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            browser Browser = new browser();
            Browser.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            notepad Notepad = new notepad();
            Notepad.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            paint Paint = new paint();
            Paint.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cmd Command = new cmd();
            Command.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            version Version = new version();
            Version.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label4.Text = DateTime.Now.ToString("t");
            label5.Text = DateTime.Now.ToString("d");
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            programfolder program = new programfolder();
            program.Show();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Recyclebin trash = new Recyclebin();
            trash.Show();
        }
    }
}
