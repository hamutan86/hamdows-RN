﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hamdows_RN
{
    public partial class taskmgr : Form
    {
        public taskmgr()
        {
            InitializeComponent();
        }

        private void taskmgr_Load(object sender, EventArgs e)
        {
            GetProcess.Start();
        }

        private void GetProcess_Tick(object sender, EventArgs e)
        {
            FormCollection openForms = Application.OpenForms;
            foreach (object obj in openForms)
            {
                Form form = (Form)obj;
                if (form.Name == "browser")
                {
                    if (!richTextBox1.Text.Contains ("webbrowser.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "webbrowser.exe";
                    }
                }
                if (form.Name == "notepad")
                {
                    if (!richTextBox1.Text.Contains("notepad.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "notepad.exe";
                    }
                }
                if (form.Name == "paint")
                {
                    if (!richTextBox1.Text.Contains("hmpaint.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "hmpaint.exe";
                    }
                }
                if (form.Name == "counter")
                {
                    if (!richTextBox1.Text.Contains("counter.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "counter.exe";
                    }
                }
                if (form.Name == "AntiVirus")
                {
                    if (!richTextBox1.Text.Contains("antivirus.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "antivirus.exe";
                    }
                }
                if (form.Name == "Todo")
                {
                    if (!richTextBox1.Text.Contains("Todo List.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "Todo List.exe";
                    }
                }
                if (form.Name == "Stopwatch")
                {
                    if (!richTextBox1.Text.Contains("stopwatch.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "stopwatch.exe";
                    }
                }
                if (form.Name == "stickynote")
                {
                    if (!richTextBox1.Text.Contains("stickynote.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "stickynote.exe";
                    }
                }
                if (form.Name == "calculator")
                {
                    if (!richTextBox1.Text.Contains("calculator.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "calculator.exe";
                    }
                }
                if (form.Name == "cmd")
                {
                    if (!richTextBox1.Text.Contains("cmd.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "cmd.exe";
                    }
                }
                if (form.Name == "version")
                {
                    if (!richTextBox1.Text.Contains("hamver.exe"))
                    {
                        richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "hamver.exe";
                    }
                }
            }
        }
    }
}
