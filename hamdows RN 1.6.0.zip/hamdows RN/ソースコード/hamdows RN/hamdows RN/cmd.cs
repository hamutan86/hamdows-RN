﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace hamdows_RN
{
    public partial class cmd : Form
    {
        public cmd()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "help")
            {
                richTextBox1.Text = "color - コマンドプロンプトの文字色を変更します。" + Environment.NewLine + "exit - コマンドプロンプトを終了します。" + Environment.NewLine + "hamver - バージョン情報を表示します。" + Environment.NewLine + "help - コマンド一覧を表示します。" + Environment.NewLine + "krnlver - カーネルのバージョンを表示します。" + Environment.NewLine + "shutdown - hamdowsをシャットダウンします。" + Environment.NewLine + "tasklist - 現在実行されているプロセスを表示します。";
            }
            if (textBox1.Text == "exit")
            {
                this.Close();
            }
            if (textBox1.Text == "hamver")
            {
                version hamver = new version();
                hamver.TopLevel = false;
                this.Controls.Add(hamver);
                hamver.Show();
                hamver.BringToFront();
            }
            if (textBox1.Text == "shutdown")
            {
                Application.Exit();
            }
            if (textBox1.Text == "tasklist")
            {
                richTextBox1.Text = "explorer.exe" + Environment.NewLine + "HamLogon.exe" + Environment.NewLine + "csrss.exe" + Environment.NewLine + "svchost.exe";
                FormCollection openForms = Application.OpenForms;
                foreach (object obj in openForms)
                {
                    Form form = (Form)obj;
                    if (form.Name == "browser")
                    {
                        if (!richTextBox1.Text.Contains("webbrowser.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "webbrowser.exe";
                        }
                    }
                    if (form.Name == "notepad")
                    {
                        if (!richTextBox1.Text.Contains("notepad.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "notepad.exe";
                        }
                    }
                    if (form.Name == "paint")
                    {
                        if (!richTextBox1.Text.Contains("hmpaint.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "hmpaint.exe";
                        }
                    }
                    if (form.Name == "counter")
                    {
                        if (!richTextBox1.Text.Contains("counter.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "counter.exe";
                        }
                    }
                    if (form.Name == "AntiVirus")
                    {
                        if (!richTextBox1.Text.Contains("antivirus.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "antivirus.exe";
                        }
                    }
                    if (form.Name == "Todo")
                    {
                        if (!richTextBox1.Text.Contains("Todo List.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "Todo List.exe";
                        }
                    }
                    if (form.Name == "Stopwatch")
                    {
                        if (!richTextBox1.Text.Contains("stopwatch.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "stopwatch.exe";
                        }
                    }
                    if (form.Name == "stickynote")
                    {
                        if (!richTextBox1.Text.Contains("stickynote.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "stickynote.exe";
                        }
                    }
                    if (form.Name == "calculator")
                    {
                        if (!richTextBox1.Text.Contains("calculator.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "calculator.exe";
                        }
                    }
                    if (form.Name == "cmd")
                    {
                        if (!richTextBox1.Text.Contains("cmd.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "cmd.exe";
                        }
                    }
                    if (form.Name == "version")
                    {
                        if (!richTextBox1.Text.Contains("hamver.exe"))
                        {
                            richTextBox1.Text = richTextBox1.Text + Environment.NewLine + "hamver.exe";
                        }
                    }
                }
            }
            if (textBox1.Text == "color")
            {
                ColorDialog colorDialog = new ColorDialog();
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    Color color = colorDialog.Color;
                    label1.ForeColor = color;
                    textBox1.ForeColor = color;
                    richTextBox1.ForeColor = color;
                }
            }
            if (textBox1.Text == "krnlver")
            {
                richTextBox1.Text = "ham kernel version" + Environment.NewLine + "hamkrnl C 3.56.00";
            }
        }
    }
}
