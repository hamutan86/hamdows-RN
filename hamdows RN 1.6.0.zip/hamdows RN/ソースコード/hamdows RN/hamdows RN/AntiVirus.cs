﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace hamdows_RN
{
    public partial class AntiVirus : Form
    {
        public AntiVirus()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            button1.Visible = false;
            richTextBox1.Text = "スキャンしています...";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.Value++;
            if (progressBar1.Value == 100)
            {
                timer1.Stop();
                button2.Visible = true;
                label1.ForeColor = Color.Red;
                label2.ForeColor = Color.Red;
                label3.ForeColor = Color.Red;
                label1.Text = "×";
                label2.Text = "このhamdowsは危険にさらされています。";
                label3.Text = "このhamdowsからウイルスが検出されました。";
                richTextBox1.Text = "C:/ユーザー/デスクトップ/プログラム/Virus.exe Trojan.ham32.Destroyer.A" + Environment.NewLine + "危険度：高 除去をお勧めします。";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            label1.ForeColor = Color.Green;
            label2.ForeColor = Color.Green;
            label3.ForeColor = Color.Green;
            label1.Text = "✔";
            label2.Text = "このhamdowsは安全です。";
            label3.Text = "このhamdowsからウイルスは見つかっていません。";
            richTextBox1.Text = "";
            File.WriteAllText("virusremoved.cfg", "virusremoved");
            MessageBox.Show("ウイルスの除去が完了しました。", "アンチウィルス", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AntiVirus_Load(object sender, EventArgs e)
        {
            button2.Visible = false;
            if (File.Exists("virusremoved.cfg"))
            {
                button1.Visible = false;
                label1.ForeColor = Color.Green;
                label2.ForeColor = Color.Green;
                label3.ForeColor = Color.Green;
                label1.Text = "✔";
                label2.Text = "このhamdowsは安全です。";
                label3.Text = "このhamdowsからウイルスは見つかっていません。";
            }
        }
    }
}
