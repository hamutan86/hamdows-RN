﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hamdows_RN
{
    public partial class calender : Form
    {
        int minutes = 0;
        int seconds = 0;
        public calender()
        {
            InitializeComponent();
        }

        private void Clock_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("D");
            label2.Text = DateTime.Now.ToString("HH") + "時" + DateTime.Now.ToString("mm") + "分" + DateTime.Now.ToString("ss") + "秒";
        }

        private void calender_Load(object sender, EventArgs e)
        {
            Clock.Start();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            minutes++;
            label3.Text = minutes.ToString() + "分" + seconds.ToString() + "秒";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            seconds++;
            label3.Text = minutes.ToString() + "分" + seconds.ToString() + "秒";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            seconds--;
            if (seconds == -1)
            {
                minutes--;
                seconds = 59;
            }
            label3.Text = minutes.ToString() + "分" + seconds.ToString() + "秒";
            if (minutes == -1)
            {
                timer.Stop();
                button1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;
                label3.Text = "0分0秒";
                seconds = 0;
                minutes = 0;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer.Stop();
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            label3.Text = "0分0秒";
            seconds = 0;
            minutes = 0;
        }

        private void calender_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer.Stop();
        }
    }
}
