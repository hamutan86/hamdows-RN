﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hamdows_RN
{
    public partial class calender : Form
    {
        public calender()
        {
            InitializeComponent();
        }

        private void Clock_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("D");
            label2.Text = DateTime.Now.ToString("HH") + "時" + DateTime.Now.ToString("mm") + "分" + DateTime.Now.ToString("ss") + "秒";
        }

        private void calender_Load(object sender, EventArgs e)
        {
            Clock.Start();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
