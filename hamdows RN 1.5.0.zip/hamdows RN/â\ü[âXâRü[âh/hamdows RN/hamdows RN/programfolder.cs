﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace hamdows_RN
{
    public partial class programfolder : Form
    {
        public programfolder()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            counter count = new counter();
            count.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("HAHA I am Virus!" + Environment.NewLine + "I Destroy Your hamdows!", "Virus.exe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            File.WriteAllText("infected.cfg", "infected");
            MessageBox.Show("重大なエラーが発生したため、hamdows RNを強制終了します。", "システム エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Desktop desktop = new Desktop();
            desktop.shutdown = 1;
            Application.Exit();
        }

        private void programfolder_Load(object sender, EventArgs e)
        {
            checkfile.Start();
            if (File.Exists("virusremoved.cfg"))
            {
                checkfile.Stop();
                pictureBox1.Visible = false;
                label2.Visible = false;
            }
        }

        private void checkfile_Tick(object sender, EventArgs e)
        {
            if (File.Exists("virusremoved.cfg"))
            {
                checkfile.Stop();
                pictureBox1.Visible = false;
                label2.Visible = false;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            AntiVirus antivirus = new AntiVirus();
            antivirus.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Todo todo = new Todo();
            todo.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Show();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            stickynote note = new stickynote();
            note.Show();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            calculator Calculator = new calculator();
            Calculator.Show();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            calender Calender = new calender();
            Calender.Show();
        }
    }
}
