﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hamdows_RN
{
    public partial class stickynote : Form
    {
        int close = 0;
        public stickynote()
        {
            InitializeComponent();
        }

        private void 新しい付箋を貼るToolStripMenuItem_Click(object sender, EventArgs e)
        {
            stickynote note = new stickynote();
            note.Show();
        }

        private void この付箋を捨てるToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 黄ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.FromArgb(192, 192, 0);
        }

        private void 青ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.Cyan;
        }

        private void ピンクToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.HotPink;
        }

        private void 緑ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.SpringGreen;
        }

        private void stickynote_Resize(object sender, EventArgs e)
        {
            richTextBox1.Size = this.Size;
        }

        private void stickynote_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (close == 0)
            {
                DialogResult dialogResult = MessageBox.Show("本当にこの付箋を捨てますか？", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    close = 1;
                    this.Close();
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }
    }
}
