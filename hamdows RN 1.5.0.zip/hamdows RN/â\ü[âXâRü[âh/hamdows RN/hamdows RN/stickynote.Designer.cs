﻿namespace hamdows_RN
{
    partial class stickynote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.メニューToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新しい付箋を貼るToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.この付箋を捨てるToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.背景色を変えるToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.黄ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.青ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ピンクToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.緑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.richTextBox1.ForeColor = System.Drawing.Color.White;
            this.richTextBox1.Location = new System.Drawing.Point(0, 27);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(234, 197);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.メニューToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(232, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // メニューToolStripMenuItem
            // 
            this.メニューToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新しい付箋を貼るToolStripMenuItem,
            this.この付箋を捨てるToolStripMenuItem,
            this.背景色を変えるToolStripMenuItem});
            this.メニューToolStripMenuItem.Name = "メニューToolStripMenuItem";
            this.メニューToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.メニューToolStripMenuItem.Text = "メニュー";
            // 
            // 新しい付箋を貼るToolStripMenuItem
            // 
            this.新しい付箋を貼るToolStripMenuItem.Name = "新しい付箋を貼るToolStripMenuItem";
            this.新しい付箋を貼るToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.新しい付箋を貼るToolStripMenuItem.Text = "新しい付箋を貼る";
            this.新しい付箋を貼るToolStripMenuItem.Click += new System.EventHandler(this.新しい付箋を貼るToolStripMenuItem_Click);
            // 
            // この付箋を捨てるToolStripMenuItem
            // 
            this.この付箋を捨てるToolStripMenuItem.Name = "この付箋を捨てるToolStripMenuItem";
            this.この付箋を捨てるToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.この付箋を捨てるToolStripMenuItem.Text = "この付箋を捨てる";
            this.この付箋を捨てるToolStripMenuItem.Click += new System.EventHandler(this.この付箋を捨てるToolStripMenuItem_Click);
            // 
            // 背景色を変えるToolStripMenuItem
            // 
            this.背景色を変えるToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.黄ToolStripMenuItem,
            this.青ToolStripMenuItem,
            this.ピンクToolStripMenuItem,
            this.緑ToolStripMenuItem});
            this.背景色を変えるToolStripMenuItem.Name = "背景色を変えるToolStripMenuItem";
            this.背景色を変えるToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.背景色を変えるToolStripMenuItem.Text = "背景色を変える";
            // 
            // 黄ToolStripMenuItem
            // 
            this.黄ToolStripMenuItem.Name = "黄ToolStripMenuItem";
            this.黄ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.黄ToolStripMenuItem.Text = "黄";
            this.黄ToolStripMenuItem.Click += new System.EventHandler(this.黄ToolStripMenuItem_Click);
            // 
            // 青ToolStripMenuItem
            // 
            this.青ToolStripMenuItem.Name = "青ToolStripMenuItem";
            this.青ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.青ToolStripMenuItem.Text = "青";
            this.青ToolStripMenuItem.Click += new System.EventHandler(this.青ToolStripMenuItem_Click);
            // 
            // ピンクToolStripMenuItem
            // 
            this.ピンクToolStripMenuItem.Name = "ピンクToolStripMenuItem";
            this.ピンクToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ピンクToolStripMenuItem.Text = "ピンク";
            this.ピンクToolStripMenuItem.Click += new System.EventHandler(this.ピンクToolStripMenuItem_Click);
            // 
            // 緑ToolStripMenuItem
            // 
            this.緑ToolStripMenuItem.Name = "緑ToolStripMenuItem";
            this.緑ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.緑ToolStripMenuItem.Text = "緑";
            this.緑ToolStripMenuItem.Click += new System.EventHandler(this.緑ToolStripMenuItem_Click);
            // 
            // stickynote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(232, 195);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "stickynote";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "付箋";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.stickynote_FormClosing);
            this.Resize += new System.EventHandler(this.stickynote_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem メニューToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新しい付箋を貼るToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem この付箋を捨てるToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 背景色を変えるToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 黄ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 青ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ピンクToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 緑ToolStripMenuItem;
    }
}