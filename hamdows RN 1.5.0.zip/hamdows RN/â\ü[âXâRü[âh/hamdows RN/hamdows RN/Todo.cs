﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hamdows_RN
{
    public partial class Todo : Form
    {
        public Todo()
        {
            InitializeComponent();
        }

        private void Todo_Load(object sender, EventArgs e)
        {
            checkBox1.Visible = false;
            checkBox2.Visible = false;
            checkBox3.Visible = false;
            checkBox4.Visible = false;
            checkBox5.Visible = false;
            checkBox6.Visible = false;
            checkBox7.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox6.Visible == true)
            {
                checkBox7.Visible = true;
                checkBox7.Text = textBox1.Text;
            }
            else
            {
                if (checkBox5.Visible == true)
                {
                    checkBox6.Visible = true;
                    checkBox6.Text = textBox1.Text;
                }
                else
                {
                    if (checkBox4.Visible == true)
                    {
                        checkBox5.Visible = true;
                        checkBox5.Text = textBox1.Text;
                    }
                    else
                    {
                        if (checkBox3.Visible == true)
                        {
                            checkBox4.Visible = true;
                            checkBox4.Text = textBox1.Text;
                        }
                        else
                        {
                            if (checkBox2.Visible == true)
                            {
                                checkBox3.Visible = true;
                                checkBox3.Text = textBox1.Text;
                            }
                            else
                            {
                                if (checkBox1.Visible == true)
                                {
                                    checkBox2.Visible = true;
                                    checkBox2.Text = textBox1.Text;
                                }
                                else
                                {
                                    checkBox1.Visible = true;
                                    checkBox1.Text = textBox1.Text;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
